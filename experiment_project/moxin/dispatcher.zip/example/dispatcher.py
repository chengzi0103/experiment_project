import json

from dora import Node, DoraStatus
import pyarrow as pa


class Operator:
    def on_event(
        self,
        dora_event,
        send_output,
    ) -> DoraStatus:
        if dora_event["type"] == "INPUT":
            send_output('run_task_num',pa.array([json.dumps('1')]),dora_event['metadata'])
        return DoraStatus.CONTINUE